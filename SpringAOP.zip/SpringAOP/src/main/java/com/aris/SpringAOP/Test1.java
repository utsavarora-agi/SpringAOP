package com.aris.SpringAOP;

import org.springframework.stereotype.Component;

@Component
public class Test1 {
public void test() {
	System.out.println("Test Function");
}
}
