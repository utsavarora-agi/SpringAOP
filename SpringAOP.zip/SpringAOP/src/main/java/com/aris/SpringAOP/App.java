package com.aris.SpringAOP;

import org.aspectj.weaver.ast.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        ApplicationContext context= new AnnotationConfigApplicationContext(AppConfig.class);
        Test1 t=context.getBean(Test1.class);
       t.test();
    }
}
